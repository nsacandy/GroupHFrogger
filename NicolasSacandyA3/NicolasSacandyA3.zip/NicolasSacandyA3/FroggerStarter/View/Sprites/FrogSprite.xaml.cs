﻿

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace FroggerStarter.View.Sprites
{
    public sealed partial class FrogSprite 
    {
        #region Constructors

        public FrogSprite()
        {
            this.InitializeComponent();
            this.IsHitTestVisible = false;
        }


        #endregion
    }
}